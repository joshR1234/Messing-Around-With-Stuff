package com.hr.app.dao;

import cogent.hr.app.domain.Employee;

public class EmployeeDAO {
	public boolean insert(Employee e) {
		// database to insert into database
		return true;

	}

}
